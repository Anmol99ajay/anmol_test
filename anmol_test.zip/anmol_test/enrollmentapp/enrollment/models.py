from django.db import models

# Create your models here.

class User(models.Model):
	Sname = models.CharField(max_length=255)
	Fname = models.CharField(max_length=255)
	DOB = models.datetime(%d,%b,%y)
	Address = models.CharField(max_length=255)
	City = models.CharField(max_length=255)
	State = models.CharField(max_length=255)
	PIN = models.string()
	Mobile = models.string()
	PIN = models.string()
	email = models.CharField(max_length=255)
	Class_opted = models.string()
	Marks = models.string()
	Date_enroll = models.datetime(%d,%b,%y)
	




